﻿<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sfa";

//create connection
$conn = new mysqli($servername, $username, $password, $dbname);

//check connection
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO `concert` (`artist`, `concert` , `showDate`, `venue`, `linkURL`) VALUES ('".$_GET["id"]"', '".$_POST["Date"]."', '".$_POST["Location"]."', '".$_POST["LinkSaleTicket"]."')";
$results_array = array();
$result = mysqli_query($con,$sql);



header("location: /sfa/MusicUpdate.php");

?>